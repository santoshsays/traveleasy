import os
import json
import time
import ast
import datetime
uname="sant"

filepath=os.path.join('/home/pi/travel/piface/dataset',"%s.txt"%uname)
timenow=str(datetime.datetime.now())
#timenow=time.asctime( time.localtime(time.time()) )
travel={'id':1234,'name':uname,'time-starts':timenow,'location1':"Mangalore"}

with open(filepath,'a+') as f:
    f.write("\n")
    #f.write('Time of Travelling %s recorded at %s.\n'%(uname,datetime.datetime.now()))
    f.write(json.dumps(travel))
    f.write("\n")

timethen=str(datetime.datetime.now())
travel.update({'time-ends':timethen,'location2':"Surathkal"})

with open(filepath,'w+') as f:
    f.write(json.dumps(travel))

#for x,y in travel.items():
    #print(x,y)

with open(filepath,'r') as f:
    content=f.read()
    mytravel=ast.literal_eval(content)

    keys = ['id','name','time-starts','location1','time-ends','location2']
    values = list( map(mytravel.get, keys) )
    for i in values:
        id=values[0]
        name=values[1]
        #time-starts=repr(values[2])
        location1=values[3]
        #time-ends=values[4]
        location2=values[5]

our_location={'Mangalore':0,'Surathkal':10,'Manipal':30,'Udupi':50}
loc1=our_location.get(location1)
loc2=our_location.get(location2)

def calculate(id,name):
    rate=10
    distance=loc2-loc1
    bill=distance*rate
    #print(id)
    #print(name)
    print("You travel from "+location1+" to "+ location2)
    print(bill)
    travel.update({'distance':distance,'bill':bill})
    with open(filepath,'w+') as f:
        f.write(json.dumps(travel))
calculate(1234,"sant")




